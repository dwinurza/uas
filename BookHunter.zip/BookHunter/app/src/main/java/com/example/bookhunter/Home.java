package com.example.bookhunter;


import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class Home extends Fragment {
    private String [] dataTitle;
    private String [] dataAuthor;
    private String [] dataSynopsis;
    private String [] dataGenre;
    private TypedArray dataPhtoo;
    private HomeAdapter adapter;
    RecyclerView recyclerView;
    private ArrayList<Book> Books;


    public Home() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_home, container, false);
        recyclerView=view.findViewById(R.id.lv_category);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);

        adapter = new HomeAdapter(getActivity());
        recyclerView.setAdapter(adapter);

        prepare();
        addItem();

        return view;


    }

    private void prepare(){
       dataTitle = getResources().getStringArray(R.array.data_title);
    }
    private void addItem(){
        Books = new ArrayList<>();
        for(int i = 0; i<dataTitle.length;i++){
            Book book = new Book();
            book.setTitle(dataTitle[i]);
            Books.add(book);
        }
        adapter.setBooks(Books);
    }

}
