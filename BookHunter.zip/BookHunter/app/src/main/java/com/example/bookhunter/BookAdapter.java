package com.example.bookhunter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Book> Books;

    public BookAdapter(ArrayList<Book> books) {
        Books = books;
    }

    public BookAdapter(Context context) {
        this.context = context;
    }
    public void setBooks(ArrayList<Book>Books){
        this.Books=Books;
    }
    public ArrayList<Book>getBooks(){
        return Books;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_book, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Book book = getBooks().get(i);
        viewHolder.tvTitle.setText(book.getTitle());
        viewHolder.tvGenre.setText(book.getGenre());
        viewHolder.tvAuthor.setText(book.getAuthor());
        viewHolder.image.setImageResource(book.getImage());

    }

    @Override
    public int getItemCount() {
        return getBooks().size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        ImageView image;
        TextView tvAuthor;
        TextView tvGenre;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);


           tvTitle = itemView.findViewById(R.id.tv_item_name);
            tvAuthor=  itemView.findViewById(R.id.buku);
            image =  itemView.findViewById(R.id.img_photo);
            tvGenre=  itemView.findViewById(R.id.genre);
            itemView.setOnClickListener(new View.OnClickListener(){
               @Override
               public void onClick(View v) {
                   int i = getAdapterPosition();
                   Intent intent = new Intent(context, BookDetails.class);
                   intent.putExtra(BookDetails.EXTRA_BOOK, Books.get(i));
                   context.startActivity(intent);
               }
           });

        }
    }
}

