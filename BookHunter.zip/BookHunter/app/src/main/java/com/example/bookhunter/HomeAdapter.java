package com.example.bookhunter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.ViewHolder> {
    private Context context;

    public HomeAdapter(Context context) {
        this.context = context;
    }

    private ArrayList<Book> Books;

    public HomeAdapter(ArrayList<Book> Books) {
        Books = Books;
    }
    public void setBooks(ArrayList<Book> Books){
        this.Books=Books;
    }
    public ArrayList<Book>getBooks(){
        return Books;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_home, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        Book book= getBooks().get(i);
        viewHolder.tvTitle.setText(book.getTitle());

    }

    @Override
    public int getItemCount() {
        return getBooks().size();

    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.list_category);
           itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    int i = getAdapterPosition();
                    Intent intent = new Intent(context, BookDetails.class);
                    intent.putExtra(BookDetails.EXTRA_BOOK, Books.get(i));
                    context.startActivity(intent);
                }
            });
        }
    }
}
