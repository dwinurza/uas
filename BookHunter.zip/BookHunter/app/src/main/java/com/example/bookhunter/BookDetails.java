package com.example.bookhunter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class BookDetails extends AppCompatActivity {
    public static final String EXTRA_BOOK = "extra_book";

    private ImageView image;
    private ImageView img;
    private TextView title;
    private TextView year;
    private TextView director;
    private TextView overview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);
    }
}
