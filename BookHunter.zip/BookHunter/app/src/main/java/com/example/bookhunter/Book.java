package com.example.bookhunter;

import android.os.Parcel;
import android.os.Parcelable;

public class Book implements Parcelable {
    private int image;
    private String title;
    private String author;
    private String synopsis;
    private String genre;

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.image);
        dest.writeString(this.title);
        dest.writeString(this.author);
        dest.writeString(this.synopsis);
        dest.writeString(this.genre);
    }

    public Book() {
    }

    protected Book(Parcel in) {
        this.image = in.readInt();
        this.title = in.readString();
        this.author = in.readString();
        this.synopsis = in.readString();
        this.genre = in.readString();
    }

    public static final Parcelable.Creator<Book> CREATOR = new Parcelable.Creator<Book>() {
        @Override
        public Book createFromParcel(Parcel source) {
            return new Book(source);
        }

        @Override
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };
}
